import postPic1 from '../img/postpic1.jpg'
import postPic2 from '../img/postpic2.jpg'
import postPic3 from '../img/postpic3.JPG'


export const PostsData = [
    {
        img: postPic1,
        name: 'Roronoa Zoro',
        desc: " “If I Die Here, Then I'm A Man That Could Only Make It This Far.”",
        likes: 100,
        liked: true
    },
    {
        img: postPic2,
        name: 'Luffy',
        desc: "I'm going to become king of the pirates. If I have to die fighting for it, then I die.",
        likes: 200,
        liked: false

    },
    {
        img:postPic3,
        name: "Luffy",
        desc: "I'm Luffy! The Man Who Will Become The Pirate King!",
        likes: 234,
        liked: false
    }
]