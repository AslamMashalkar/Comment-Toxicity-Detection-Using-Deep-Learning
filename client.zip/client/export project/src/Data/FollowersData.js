import img5 from "../img/img5.png";
import img2 from "../img/img2.png";
import img3 from "../img/img3.png";
import img4 from "../img/img4.jpg";

export const Followers = [
  { name: "Monkey D Luffy", username: "Luffysan", img: img5 },
  { name: "Ace D Roger", username: "Ace", img: img2 },
  { name: "Sanji", username: "SanjiSan", img: img3 },
  { name: "Trafalgar D.Water Law", username: "Law", img: img4 },
];