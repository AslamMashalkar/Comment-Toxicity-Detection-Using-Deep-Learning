// import React from 'react'
// import './Post.css'
// import Comment from '../../img/comment.png'
// import Share from '../../img/share.png'
// import Heart from '../../img/like.png'
// import NotLike from '../../img/notlike.png'

// const Post = ({data}) => {
//   return (
//     <div className="Post">
//         <img src={data.img} alt="" />

//         <div className="postReact">
//             <img src={data.liked?Heart: NotLike} alt="" />
//             <img src={Comment} alt="" />
//             <img src={Share} alt="" />
//         </div>


//         <span style={{color: "var(--gray)", fontSize: '12px'}}>{data.likes} likes</span>

//         <div className="detail">
//             <span><b>{data.name}</b></span>
//             <span> {data.desc}</span>
//         </div>
//     </div>
//   )
// }

// export default Post


import React, { useState } from 'react';
import './Post.css';
import CommentIcon from '../../img/comment.png';
import ShareIcon from '../../img/share.png';
import LikeIcon from '../../img/like.png';
import NotLikeIcon from '../../img/notlike.png';

const Post = ({ data }) => {
  const [showComments, setShowComments] = useState(false);
  const [comments, setComments] = useState([]);
  const [newComment, setNewComment] = useState('');
  const [showAddComment, setShowAddComment] = useState(false);

  // Function to handle input change in the comment input field
  const handleInputChange = (event) => {
    setNewComment(event.target.value);
  };

  // Function to add comment
  const addComment = () => {
    if (newComment.trim() !== '') {
      setComments([...comments, newComment]);
      setNewComment(''); // Clear the input field after adding a comment
      setShowComments(true); // Show comments after adding a new comment
    }
  };

  // Function to handle comment icon click
  const handleCommentIconClick = () => {
    setShowAddComment(!showAddComment); // Toggle the visibility of the comment input box
  };

  return (
    <div className="Post">
      <img src={data.img} alt="" />

      <div className="postReact">
        <img src={data.liked ? LikeIcon : NotLikeIcon} alt="" />
        <img src={CommentIcon} alt="" onClick={handleCommentIconClick} />
        <img src={ShareIcon} alt="" />
      </div>

      <span style={{ color: "var(--gray)", fontSize: '12px' }}>{data.likes} likes</span>

      <div className="detail">
        <span><b>{data.name}</b></span>
        <span> {data.desc}</span>
      </div>

      {/* Render comments if showComments is true */}
      {showComments && (
        <div className="comments">
          <h3>Comments</h3>
          <ul>
            {comments.map((comment, index) => (
              <li key={index}>{comment}</li>
            ))}
          </ul>
        </div>
      )}

      {/* Render comment input box if showAddComment is true */}
      {showAddComment && (
        <div className="add-comment">
          <input
            type="text"
            placeholder="Add a comment"
            value={newComment}
            onChange={handleInputChange}
          />
          <button onClick={addComment}>Add Comment</button>
        </div>
      )}
    </div>
  );
};

export default Post;
