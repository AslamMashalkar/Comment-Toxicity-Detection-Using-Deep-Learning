import React from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import "./App.css";
// import Auth from "./pages/Auth/Auth";
import Profile from "./pages/Profile/Profile";
import Home from "./pages/home/Home";
import Auth from "./pages/Auth/Auth";

function App() {
  return (
    <div className="App">
      <div className="blur" style={{ top: "-18%", right: "0" }}></div>
      <div className="blur" style={{ top: "36%", left: "-8rem" }}></div>

      <BrowserRouter>
        <Routes>
          <Route path="/profile" element={<Profile/> }/>
        <Route path="/login" element={<Auth />} />
          <Route exact path="/" element={<Home />} />
          
        </Routes>
        
      </BrowserRouter>
    </div>
  );
}

export default App;
