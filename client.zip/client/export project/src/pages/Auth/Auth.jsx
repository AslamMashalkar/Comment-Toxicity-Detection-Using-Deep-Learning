import React, { useState } from "react";
import "./Auth.css";
import Logo from "../../img/logo.png";
import { useDispatch } from 'react-redux';
import { logIn, signUp } from "../../api/AuthRequest";
import { useNavigate } from "react-router-dom"
import axios from "axios";
const Auth = () => {
  const [isSignUp, setIsSignUp] = useState(true);
  // const dispatch = useDispatch();
  const navigate = useNavigate();
  const [data, setData] = useState({
    firstname: "",
    lastname: "",
    username: "",
    password: "",
    confirmpass: ""
  });

  const [confirmPass, setConfirmPass] = useState(true);

  const handleChange = (e) => {
    setData({ ...data, [e.target.name]: e.target.value });
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    
    if (isSignUp) {
      data.password === data.confirmpass ?
      // dispatch(signUp(data)) : setConfirmPass(false);
      
      navigate(signUp(data)) : setConfirmPass(false);
    } else {
      const loginData = {username:data.username, password:data.password}
      // dispatch(logIn(data));
      // console.log("LOGIN DATA", loginData)
      // axios.post('http://localhost:5000/Auth/login', loginData).then(res => console.log(res)).catch(err=> console.log(err))
      // logIn(loginData)
      // console.log({data:{username:"pranit", password:"spapapa"}})
      try {
        const response =  axios.post('http://localhost:5000/Auth/login', loginData);
        console.log(response);
        
        if (response.status === 200) {
          // Assuming you're using React Router for navigation
          navigate('/') // Navigate to the root URL
        }
      } catch (error) {
        console.log(error);
      }

      navigate('/')

    }
  };

  const resetForm = () => {
    setConfirmPass(true);
    setData({
      firstname: "", lastname: "", username: "", password: "", confirmpass: ""
    });
  };

  return (
    <div className="Auth">
      {/* Left Side */}
      <div className="a-left">
        <img src={Logo} alt="" />
        <div className="Webname">
          <h1>Social Idea</h1>
          <h6>Explore the ideas through Social Media Website</h6>
        </div>
      </div>

      {/* right side */}
      <div className="a-right">
        <form className="infoForm authForm" onSubmit={handleSubmit}>
          <h3>{isSignUp ? "Sign up" : "Log In"}</h3>

          {isSignUp && (
            <div>
              <input
                type="text"
                placeholder="First Name"
                className="infoInput"
                name="firstname"
                onChange={handleChange}
              />
              <input
                type="text"
                placeholder="Last Name"
                className="infoInput"
                name="lastname"
                onChange={handleChange}
              />
            </div>
          )}

          <div>
            <input
              type="text"
              className="infoInput"
              name="username"
              placeholder="Usernames"
              onChange={handleChange}
            />
          </div>

          <div>
            <input
              type="password"
              className="infoInput"
              name="password"
              placeholder="Password"
              onChange={handleChange}
            />

            {isSignUp && (
              <input
                type="password"
                className="infoInput"
                name="confirmpass"
                placeholder="Confirm Password"
                onChange={handleChange}
                value={data.confirmpass}
              />
            )}
          </div>
          <span style={{
            display: confirmPass ? "none" : "block",
            color: "red",
            fontSize: "12px",
            alignSelf: "flex-end",
            marginRight: "5px",
          }}>
            * Confirm Password is not same
          </span>
          <div>
            <span
              style={{ fontSize: "12px", cursor: "pointer" }}
              onClick={() => { setIsSignUp((prev) => !prev); resetForm() }}
            >
              {isSignUp
                ? "Already have an account. Login!"
                : "Dont have an account? Sign Up"}
            </span>
          </div>
          <button className="button infoButton" type="submit">
            {isSignUp ? "Signup" : "Log In"}
          </button>
        </form>
      </div>
    </div>
  );
};

export default Auth;
